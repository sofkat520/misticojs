const http = require('http');
const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');

const PORT = process.env.PORT || 3000;

// Pool de conexiones a MySQL
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '', // Si configuraste clave en phpMyAdmin, ponla aquí
  database: 'catalogo_alimentos',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Evita inyección de HTML en los textos
const esc = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])
  );

// Convertidor de precio ultra seguro (evita errores si MySQL devuelve string o decimal)
const precio = (n) => {
  const num = parseFloat(n);
  return '$' + (isNaN(num) ? '0.00' : num.toFixed(2));
};

// Plantilla layout
const layout = (titulo, descripcion, contenido) => `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${esc(titulo)}</title>
  <meta name="description" content="${esc(descripcion)}">
  <link rel="stylesheet" href="/styles.css">
</head>
<body>
  <header class="cabecera">
    <a href="/" class="logo">🥑 Sabores del Campo</a>
    <span>Catálogo virtual</span>
  </header>
  <main class="contenedor">${contenido}</main>
  <footer class="pie">© ${new Date().getFullYear()} Sabores del Campo</footer>
</body>
</html>`;

// Página principal: Lista desde MySQL
const paginaIndex = async () => {
  // Consulta directa a MySQL
  const [productos] = await pool.query('SELECT * FROM productos');

  const tarjetas = productos
    .map(
      (p) => `
    <article class="tarjeta">
      <div class="imagen">${esc(p.emoji)}</div>
      <span class="etiqueta">${esc(p.categoria)}</span>
      <h2>${esc(p.nombre)}</h2>
      <p class="precio">${precio(p.precio)}</p>
      <a class="boton" href="/producto/${p.id}">Ver detalle</a>
    </article>`
    )
    .join('');

  return layout(
    'Catálogo de alimentos | Sabores del Campo',
    'Explora nuestro catálogo de alimentos naturales: granos, café, miel, aceites y más.',
    `<h1>Nuestros productos (${productos.length})</h1><section class="grilla">${tarjetas}</section>`
  );
};

// Página de detalle
const paginaDetalle = (p) => {
  let listaIngredientes = [];
  try {
    listaIngredientes = typeof p.ingredientes === 'string'
      ? JSON.parse(p.ingredientes || '[]')
      : (p.ingredientes || []);
  } catch (e) {
    listaIngredientes = [];
  }

  const ingredientesHtml = listaIngredientes.map((i) => `<li>${esc(i)}</li>`).join('');

  return layout(
    `${p.nombre} | Sabores del Campo`,
    p.descripcion,
    `<a class="volver" href="/">← Volver al catálogo</a>
    <article class="detalle">
      <div class="imagen grande">${esc(p.emoji)}</div>
      <div class="info">
        <span class="etiqueta">${esc(p.categoria)}</span>
        <h1>${esc(p.nombre)}</h1>
        <p class="precio grande-precio">${precio(p.precio)}</p>
        <p>${esc(p.descripcion)}</p>
        <ul class="datos">
          <li><strong>Presentación:</strong> ${esc(p.peso)}</li>
          <li><strong>Origen:</strong> ${esc(p.origen)}</li>
        </ul>
        <h3>Ingredientes</h3>
        <ul>${ingredientesHtml}</ul>
      </div>
    </article>`
  );
};

const pagina404 = () =>
  layout(
    'Página no encontrada',
    'La página solicitada no existe.',
    '<h1>404</h1><p>No encontramos lo que buscas.</p><a class="volver" href="/">← Volver al catálogo</a>'
  );

const enviar = (res, codigo, tipo, cuerpo) => {
  res.writeHead(codigo, { 'Content-Type': `${tipo}; charset=utf-8` });
  res.end(cuerpo);
};

// Servidor HTTP
const servidor = http.createServer(async (req, res) => {
  try {
    const { pathname } = new URL(req.url, `http://${req.headers.host}`);

    if (pathname === '/') {
      const html = await paginaIndex();
      return enviar(res, 200, 'text/html', html);
    }

    const coincide = pathname.match(/^\/producto\/(\d+)$/);
    if (coincide) {
      const [rows] = await pool.execute('SELECT * FROM productos WHERE id = ?', [coincide[1]]);
      const producto = rows[0];

      return producto
        ? enviar(res, 200, 'text/html', paginaDetalle(producto))
        : enviar(res, 404, 'text/html', pagina404());
    }

    if (pathname === '/styles.css') {
      return fs.readFile(path.join(__dirname, 'public', 'styles.css'), (err, css) =>
        err ? enviar(res, 404, 'text/plain', 'No encontrado') : enviar(res, 200, 'text/css', css)
      );
    }

    enviar(res, 404, 'text/html', pagina404());
  } catch (error) {
    console.error('❌ Error en el servidor:', error);
    enviar(res, 500, 'text/plain', 'Error al consultar la base de datos');
  }
});

servidor.listen(PORT, () => {
  console.log(`Servidor MySQL listo en http://localhost:${PORT}`);
});