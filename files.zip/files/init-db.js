const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');

async function inicializarBD() {
  // Configuración por defecto de XAMPP / WAMP
  const conexion = await mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '', // En XAMPP suele ir vacío. Si tienes clave en phpMyAdmin, ponla aquí.
    database: 'catalogo_alimentos'
  });

  console.log('Conectado a MySQL/phpMyAdmin...');

  // 1. Crear tabla si no existe
  await conexion.query(`
    CREATE TABLE IF NOT EXISTS productos (
      id INT AUTO_INCREMENT PRIMARY KEY,
      nombre VARCHAR(150) NOT NULL,
      categoria VARCHAR(100) NOT NULL,
      precio DECIMAL(10,2) NOT NULL,
      peso VARCHAR(50) NOT NULL,
      origen VARCHAR(100) NOT NULL,
      emoji VARCHAR(10) NOT NULL,
      descripcion TEXT NOT NULL,
      ingredientes JSON NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  `);

  // 2. Leer productos.json
  const rutaJson = path.join(__dirname, 'data', 'productos.json');
  if (fs.existsSync(rutaJson)) {
    const productos = JSON.parse(fs.readFileSync(rutaJson, 'utf8'));

    // Limpiar tabla previa
    await conexion.query('TRUNCATE TABLE productos');

    // Insertar productos
    for (const p of productos) {
      await conexion.execute(
        `INSERT INTO productos (id, nombre, categoria, precio, peso, origen, emoji, descripcion, ingredientes)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          p.id,
          p.nombre,
          p.categoria,
          p.precio,
          p.peso,
          p.origen,
          p.emoji,
          p.descripcion,
          JSON.stringify(p.ingredientes)
        ]
      );
    }
    console.log('✅ Base de datos "catalogo_alimentos" poblada correctamente.');
  }

  await conexion.end();
}

inicializarBD().catch((err) => {
  console.error('❌ Error al inicializar MySQL:', err);
});