require("dotenv").config();
const path = require("path");
const express = require("express");
const session = require("express-session");

const publicRoutes = require("./routes/public");
const adminRoutes = require("./routes/admin");

const app = express();

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(
  session({
    secret: process.env.SESSION_SECRET || "mistico_secret",
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 1000 * 60 * 60 * 4 }, // 4 horas
  })
);

// Archivos estáticos: css/js/img/fonts publicos y admin/public, admin/scripts
app.use(express.static(path.join(__dirname, "public")));

// Carpeta de archivos subidos (imágenes/pdf de ofertas) -> misma ruta que el
// proyecto original: admin/files/ofertas/<archivo>
app.use("/admin/files/ofertas", express.static(path.join(__dirname, "uploads/ofertas")));

// Rutas públicas (home, tours)
app.use("/", publicRoutes);

// Rutas del panel admin (vistas + API que reemplaza admin/ajax/*.php)
app.use("/admin", adminRoutes);

// 404 simple
app.use((req, res) => {
  res.status(404).send("Página no encontrada");
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Cusco Mistico Travel corriendo en http://localhost:${PORT}`);
});
