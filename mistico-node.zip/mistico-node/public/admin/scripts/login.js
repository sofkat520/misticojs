$("#frmAcceso").on('submit',function(e)
{
	e.preventDefault();
    logina=$("#logina").val();
    clavea=$("#clavea").val();
    $.post("/admin/api/login",
        {"logina":logina,"clavea":clavea},
        function(data)
        {

        if (data!=null)
        {

            $(location).attr("href","/admin/ofertas");
        }
        else
        {

            bootbox.alert("Usuario y/o Password incorrectos");
        }
        });
})
