// Reemplaza la verificación "if (!isset($_SESSION['nombre'])) header('Location: login.html')"
function requireAdminView(req, res, next) {
  if (!req.session || !req.session.nombre) {
    return res.redirect("/admin/login");
  }
  next();
}

// Para los endpoints /admin/api/* que son llamados por fetch/ajax:
// si no hay sesión respondemos 401 en vez de redirigir.
function requireAdminApi(req, res, next) {
  if (!req.session || !req.session.nombre) {
    return res.status(401).json({ error: "No autorizado" });
  }
  next();
}

module.exports = { requireAdminView, requireAdminApi };
