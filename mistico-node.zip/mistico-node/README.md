# Cusco Mistico Travel — versión Node.js

Migración del proyecto original (PHP + XAMPP) a **Node.js + Express + EJS + MySQL**,
manteniendo el mismo diseño (CSS, header y footer) tanto del sitio público como
del panel de administración, con rutas limpias (sin `.php` ni `.html` visibles).

## 1. Requisitos
- Node.js 18 o superior
- MySQL / MariaDB (puede seguir siendo el mismo que usabas con XAMPP)

## 2. Instalación

```bash
npm install
cp .env.example .env
```

Edita `.env` con los datos de tu base de datos (por defecto usuario `root` sin
password, igual que el proyecto original).

## 3. Base de datos

Importa `database.sql` en tu MySQL (es el mismo esquema que tenías: tablas
`oferta`, `tour` y `usuario`):

```bash
mysql -u root -p < database.sql
# o crea la base "cuscomistico" primero si no existe:
mysql -u root -p -e "CREATE DATABASE IF NOT EXISTS cuscomistico"
mysql -u root -p cuscomistico < database.sql
```

## 4. Ejecutar

```bash
npm start
```

Abre `http://localhost:3000`.

Panel admin: `http://localhost:3000/admin/login`
(usuarios de ejemplo ya en la BD: `antonio` / `1234`, `ramiro` / `1234`)

## 5. Rutas (todas limpias, sin extensión)

**Público**
- `GET /` — Home (antes `index.php`)
- `GET /tour/:id` — Detalle de un tour (antes `tour.php?id=`)

**Admin**
- `GET /admin/login` — Login (antes `admin/vistas/login.html`)
- `GET /admin/ofertas` — Panel de ofertas (antes `admin/vistas/oferta.php`), protegido por sesión
- `POST /admin/api/login` — Verifica credenciales (antes `admin/ajax/usuario.php?op=verificar`)
- `POST /admin/api/logout` — Cierra sesión (antes `op=salir`)
- `GET /admin/api/ofertas` — Listado (DataTables)
- `GET /admin/api/ofertas/:id` — Detalle de una oferta
- `POST /admin/api/ofertas` — Crear/editar (multipart, sube imagen y PDF)
- `POST /admin/api/ofertas/:id/activar` / `/desactivar`

## 6. Qué se mantuvo igual
- Los mismos estilos CSS (Bootstrap, AdminLTE, custom `style.css`, etc.)
- El mismo `header` y `footer` del sitio público y del admin
- La misma estructura de la base de datos y los mismos datos
- El editor de texto enriquecido (nicEdit), DataTables, subida de archivos, etc.

## 7. Qué cambió técnicamente
- PHP/mysqli → Node.js/Express con `mysql2` (consultas parametrizadas, más seguras contra inyección SQL que el PHP original)
- Sesiones PHP (`$_SESSION`) → `express-session`
- Subida de archivos (`move_uploaded_file`) → `multer`
- Vistas `.php` → plantillas `.ejs` (mismo HTML, solo cambia la sintaxis de las partes dinámicas)
- Rutas con `.php`/`.html` visibles → rutas limpias vía Express

## 8. Puntos a revisar / mejorar (heredados del proyecto original)
- **Contraseñas en texto plano**: la tabla `usuario` guarda `pass` sin hash y el
  login original comparaba texto plano (aunque el alta de "usuarios admin"
  usaba SHA256, esa parte del CRUD de usuarios no tiene vista asociada en el
  proyecto, solo existe el login). Se mantuvo igual para no invalidar las
  credenciales existentes, pero se recomienda migrar a `bcrypt` cuanto antes.
- **Campo `cuerpo` de `oferta`**: el PHP original tenía un bug que guardaba el
  texto literal `htmlspecialchars(...)` alrededor del contenido en vez de
  llamar a la función. Se replicó el mismo formato en el backend Node para
  seguir siendo compatible con los datos ya existentes y con el recorte que
  hace la página de inicio. Si quieres limpiarlo de raíz, dímelo y lo
  corregimos en una pasada (hay que tocar 3 puntos a la vez).
- El CRUD de "usuarios" del admin (`admin/modelos/Usuario.php`) no tenía
  ninguna vista real asociada en el proyecto (no existe `admin/vistas/usuario.php`),
  así que no se migró — si lo necesitas, lo agrego.
