const express = require("express");
const router = express.Router();
const db = require("../config/db");

// Reemplaza index.php: $oferta->mostrar_todo() -> SELECT * from oferta where estado='1' order by id_oferta desc
router.get("/", async (req, res) => {
  try {
    const [ofertas] = await db.query(
      "SELECT * FROM oferta WHERE estado='1' ORDER BY id_oferta DESC"
    );

    // Reproduce la lógica de index.php:
    // - $resultado = substr(htmlspecialchars_decode($r['cuerpo']), 17, strlen(...)-18)
    // - $division = explode('[', $r['incluye'])  (se parte en 2 columnas)
    const ofertasProcesadas = ofertas.map((r) => {
      const cuerpoDecodificado = decodeHtmlEntities(r.cuerpo || "");
      const cuerpo = cuerpoDecodificado.substring(17, cuerpoDecodificado.length - 18);

      let incluyeIzquierda = [];
      let incluyeDerecha = [];
      if (r.incluye) {
        const division = r.incluye.split("[");
        const cantidades = (countOcurrences(r.incluye, "[") + 1) / 2;
        const separar = Math.ceil(cantidades);
        incluyeIzquierda = division.slice(0, separar);
        incluyeDerecha = division.slice(separar);
      }

      return { ...r, cuerpo, incluyeIzquierda, incluyeDerecha };
    });

    res.render("index", { ofertas: ofertasProcesadas });
  } catch (err) {
    console.error(err);
    res.status(500).send("Error al cargar la página principal");
  }
});

// Reemplaza tour.php (?id=) con una ruta limpia /tour/:id
router.get("/tour/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10) || 0;
    const [rows] = await db.query(
      "SELECT * FROM tour WHERE id_tour=? AND estado='1'",
      [id]
    );
    const tour = rows[0] || null;
    res.render("tour", { tour });
  } catch (err) {
    console.error(err);
    res.status(500).send("Error al cargar el tour");
  }
});

// Reemplaza la regla de .htaccess:
// RewriteRule ^paquetes-turisticos-cusco-tradicional-4d.html$ tour.php?slug=...
router.get("/paquetes-turisticos-cusco-tradicional-4d", async (req, res) => {
  res.redirect("/tour/3");
});

function decodeHtmlEntities(str) {
  const map = { "&amp;": "&", "&lt;": "<", "&gt;": ">", "&quot;": '"', "&#039;": "'" };
  return str.replace(/&amp;|&lt;|&gt;|&quot;|&#039;/g, (m) => map[m]);
}

function countOcurrences(str, sub) {
  return str.split(sub).length - 1;
}

module.exports = router;
