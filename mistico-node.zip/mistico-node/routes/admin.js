const express = require("express");
const path = require("path");
const fs = require("fs");
const multer = require("multer");
const router = express.Router();
const db = require("../config/db");
const { requireAdminView, requireAdminApi } = require("../middlewares/auth");

const UPLOAD_DIR = path.join(__dirname, "..", "uploads", "ofertas");

// --- Multer: reemplaza move_uploaded_file() de admin/ajax/oferta.php ---
// El original conserva el nombre original del archivo (primer y último
// fragmento separado por "."), lo replicamos igual.
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const parts = file.originalname.split(".");
    const nombre = parts.length > 1 ? `${parts[0]}.${parts[parts.length - 1]}` : file.originalname;
    cb(null, nombre);
  },
});
const upload = multer({ storage });

/* ======================= VISTAS (páginas) ======================= */

// Reemplaza admin/index.php -> redirige al login
router.get("/", (req, res) => res.redirect("/admin/login"));

// Reemplaza admin/vistas/login.html
router.get("/login", (req, res) => {
  if (req.session && req.session.nombre) return res.redirect("/admin/ofertas");
  res.render("admin/login");
});

// Reemplaza admin/vistas/oferta.php (vista protegida)
router.get("/ofertas", requireAdminView, (req, res) => {
  res.render("admin/ofertas", { nombre: req.session.nombre });
});

/* ======================= API: usuario (login/logout) =======================
   Reemplaza admin/ajax/usuario.php?op=verificar y op=salir               */

router.post("/api/login", async (req, res) => {
  try {
    const { logina, clavea } = req.body;
    // Nota: el proyecto original compara la contraseña en texto plano
    // (no usa el hash SHA256 que sí aplica al crear usuarios). Se respeta
    // el mismo comportamiento para no romper las credenciales existentes;
    // se recomienda migrar a bcrypt/hash + compare cuanto antes.
    const [rows] = await db.query(
      "SELECT id_usuario, usuario, pass, tipo FROM usuario WHERE usuario=? AND pass=?",
      [logina, clavea]
    );
    const user = rows[0];
    if (user) {
      req.session.idusuario = user.id_usuario;
      req.session.nombre = user.usuario;
      return res.json(user);
    }
    return res.json(null);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Error de servidor" });
  }
});

router.post("/api/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/admin/login");
  });
});

/* ======================= API: ofertas =======================
   Reemplaza admin/ajax/oferta.php (todas las operaciones)    */

// listar -> formato esperado por DataTables (legado, igual al original)
router.get("/api/ofertas", requireAdminApi, async (req, res) => {
  try {
    const [rows] = await db.query("SELECT * FROM oferta ORDER BY id_oferta DESC");
    const data = rows.map((r) => [
      r.estado
        ? `<button class="btn btn-warning" onclick="mostrar(${r.id_oferta})"><i class="fa fa-pencil"></i></button> <button class="btn btn-danger" onclick="desactivar(${r.id_oferta})"><i class="fa fa-close"></i></button>`
        : `<button class="btn btn-warning" onclick="mostrar(${r.id_oferta})"><i class="fa fa-pencil"></i></button> <button class="btn btn-primary" onclick="activar(${r.id_oferta})"><i class="fa fa-check"></i></button>`,
      r.titulo,
      stripTags(decodeEntities(r.cuerpo || "")).substring(17, 97) + "...",
      r.incluye,
      `<a href="/admin/files/ofertas/${r.archivo}" target="_blank"><i class="fa fa-file"></i> ${r.archivo}</a>`,
      `<img width="150px" height="120px" src="/admin/files/ofertas/${r.imagen}"></img>`,
      r.estado
        ? '<span class="label bg-green">Activado</span>'
        : '<span class="label bg-red">Desactivado</span>',
    ]);
    res.json({
      sEcho: 1,
      iTotalRecords: data.length,
      iTotalDisplayRecords: data.length,
      aaData: data,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Error al listar ofertas" });
  }
});

// mostrar (para editar)
router.get("/api/ofertas/:id", requireAdminApi, async (req, res) => {
  try {
    const [rows] = await db.query("SELECT * FROM oferta WHERE id_oferta=?", [req.params.id]);
    res.json(rows[0] || null);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Error al obtener la oferta" });
  }
});

// guardar y editar (crea o actualiza según venga idoferta)
router.post(
  "/api/ofertas",
  requireAdminApi,
  upload.fields([{ name: "imagen", maxCount: 1 }, { name: "archivo", maxCount: 1 }]),
  async (req, res) => {
    try {
      const b = req.body;
      const idoferta = b.idoferta || "";
      const titulo = b.titulo || "";
      // NOTA (compatibilidad con datos existentes): el proyecto PHP original
      // tenía un bug en admin/modelos/Oferta.php: en vez de llamar a la
      // función htmlspecialchars($cuerpo), la guardaba como texto literal
      // 'htmlspecialchars(' + contenido + ')' dentro de la columna `cuerpo`.
      // El home (index) y este mismo panel luego recortan esos 17/1
      // caracteres para mostrar el contenido real (ver routes/public.js y
      // oferta.js -> función mostrar()). Se replica aquí ese mismo formato
      // para que las ofertas nuevas sean compatibles con esa lógica ya
      // existente en el resto del sistema. Si prefieres corregirlo de raíz,
      // quita este envoltorio y ajusta a la vez el recorte en public.js y
      // en public/admin/scripts/oferta.js (función mostrar).
      const cuerpo = "htmlspecialchars(" + (b.editor || "") + ")";

      // Construye "incluye" igual que el original: items separados por "["
      const items = [b.uno, b.dos, b.tres, b.cuatro, b.cinco, b.seis, b.siete, b.ocho];
      const cantidad = parseInt(b.item || "0", 10);
      const incluye = cantidad > 0 ? items.slice(0, cantidad).join("[") : "";

      const imagen =
        req.files && req.files.imagen && req.files.imagen[0]
          ? req.files.imagen[0].filename
          : b.imagenactual || "";
      const archivo =
        req.files && req.files.archivo && req.files.archivo[0]
          ? req.files.archivo[0].filename
          : b.archivoactual || "";

      if (!idoferta) {
        await db.query(
          "INSERT INTO oferta (titulo, cuerpo, incluye, imagen, archivo, estado) VALUES (?,?,?,?,?,1)",
          [titulo, cuerpo, incluye, imagen, archivo]
        );
        return res.send("Oferta registrada");
      } else {
        await db.query(
          "UPDATE oferta SET titulo=?, imagen=?, cuerpo=?, incluye=?, archivo=? WHERE id_oferta=?",
          [titulo, imagen, cuerpo, incluye, archivo, idoferta]
        );
        return res.send("Oferta actualizada");
      }
    } catch (err) {
      console.error(err);
      res.status(500).send("Oferta no se pudo guardar");
    }
  }
);

router.post("/api/ofertas/:id/desactivar", requireAdminApi, async (req, res) => {
  try {
    await db.query("UPDATE oferta SET estado='0' WHERE id_oferta=?", [req.params.id]);
    res.send("Oferta Desactivado");
  } catch (err) {
    console.error(err);
    res.status(500).send("Oferta no se puede desactivar");
  }
});

router.post("/api/ofertas/:id/activar", requireAdminApi, async (req, res) => {
  try {
    await db.query("UPDATE oferta SET estado='1' WHERE id_oferta=?", [req.params.id]);
    res.send("Oferta activado");
  } catch (err) {
    console.error(err);
    res.status(500).send("Oferta no se puede activar");
  }
});

function stripTags(html) {
  return html.replace(/<[^>]*>/g, "");
}
function decodeEntities(str) {
  const map = { "&amp;": "&", "&lt;": "<", "&gt;": ">", "&quot;": '"', "&#039;": "'" };
  return str.replace(/&amp;|&lt;|&gt;|&quot;|&#039;/g, (m) => map[m]);
}

module.exports = router;
