// Reemplaza a clases/Conexion.php y admin/config/Conexion.php
// Usa un pool de conexiones mysql2 (promesas) en vez de mysqli.
require("dotenv").config();
const mysql = require("mysql2/promise");

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "cuscomistico",
  charset: "utf8mb4",
  waitForConnections: true,
  connectionLimit: 10,
});

module.exports = pool;
